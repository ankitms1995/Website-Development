<?php
 
require_once 'include/DB_Functions.php';
$db = new DB_Functions();
 
// json response array
$response = array("error" => FALSE);
var_dump($_POST);

if (isset($_POST['ticket_no']) && isset($_POST['name']) && isset($_POST['phone_no']) && isset($_POST['email']) && isset($_POST['college']) && isset($_POST['event'])) {
 
    // receiving the post params
    $ticketno = $_POST['ticket_no'];
    $name = $_POST['name'];
    $phno = $_POST['phone_no'];
    $email = $_POST['email'];
    $college = $_POST['college'];
    $event = $_POST['event'];
 
    // check if user is already existed with the same email
    if ($db->isUserExisted($ticketno)) {
        // user already existed
        $response["error"] = TRUE;
        $response["error_msg"] = "User already existed with " . $ticketno;
        echo json_encode($response);
    } else {
        // create a new user
        $user = $db->storeUser($ticketno, $name, $phno, $email, $college, $event);
        if ($user) {
            // user stored successfully
            $response["error"] = FALSE;
            $response["user"]["ticket_number"] = $user["TICKET_NO"];
            $response["user"]["name"] = $user["NAME"];
            $response["user"]["number"] = $user["PHONE_NO"];
            $response["user"]["email"] = $user["EMAIL"];
            $response["user"]["college"] = $user["COLLEGE"];
            $response["user"]["event"] = $user["EVENT"];
            echo json_encode($response);
            
        } else {
            // user failed to store
            $response["error"] = TRUE;
            $response["error_msg"] = "Unknown error occurred in registration!Please try Re-registering!!";
            echo json_encode($response);
        }
    }
} else {
    $response["error"] = TRUE;
    $response["error_msg"] = "Required parameters (Ticket No, Name, Phone No., Email , College or Event) is missing!!";
    echo json_encode($response);
}
?>