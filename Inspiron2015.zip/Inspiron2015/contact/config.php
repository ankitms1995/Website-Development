<?php
// To
define("WEBMASTER_EMAIL", 'ecell.uvce@gmail.com');
?>
