<?php
function set_count($filename='counter.txt')
{
	if(file_exists($filename))
	{
		$handle=fopen($filename,'r');
		$count=(int)fread($handle,20)+1;
		$handle=fopen($filename,'w');
		fwrite($handle, $count);
		fclose($handle);
		return $count;
	}
	else
	{
		$handle=fopen($filename,'w+');
		fwrite($handle, 1);
		fclose($handle);
		return 1;
	}
}
$count = set_count();
?>