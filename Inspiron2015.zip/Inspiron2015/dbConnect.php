<?php
	define("DB_HOST", "52.192.228.70:3306");
	define("DB_USER", "team_b");
	define("DB_PASSWORD", "teamb227");
	define("DB_DATABASE", "hackaton_hul_team_b");
	
	$conn = mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD,DB_DATABASE) or die('Unable to Connect');
	$results = $conn->query('SELECT * FROM T_PROMOTION_INFO');
 	$rows = array();
	while($r = mysqli_fetch_assoc($results)) {
    	$rows[] = $r;
	}
	print json_encode($rows);
?>
