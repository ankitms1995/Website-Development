<?php
session_start();
try{
	if(!isset($_SESSION['username']))
	{
		header('Location: login.php');
	}
	require_once 'include/config.php';
	$conn = new mysqli(DB_HOST,DB_USER,DB_PASSWORD,DB_DATABASE);
	//$conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
	?>
	<!DOCTYPE html>
	<html>
	<head>
		<title>deleteday2</title>
	</head>
	<body>
	<form action="deleteday2.php" method="post">
		<label for="event_name">event_name</label>
		<input type="text" name="event_name" id="event_name">
		<input type="submit" value="go">
	</form>
	</body>
	</html>
	<?php
	if($_SERVER['REQUEST_METHOD']=='POST')
	{
		$event_name=$_POST['event_name'];
		if($event_name!="")
		{
			$stmt = $conn->prepare("DELETE from DAY2 WHERE event_name=(?)");
	    	$stmt->bind_param('s',$event_name);
	   	 	$result = $stmt->execute();
	    	$stmt->close();
	    	echo "Deleted!";
	    }
		/*$results=$conn->query('SELECT * FROM DAY2');
		foreach($results as $row)
		{
			foreach($row as $name=>$value)
			{	echo $value;	
			}
			echo "</br>";
		}*/
	}
	/*else
	{
		echo "Not Post!";
	}*/
	echo '<br/><br/><a href="logout.php">logout</a>';
}	
catch(PDOException $e)
{
	echo 'ERROR: '.$e->getMessage();
}
?>
