<?php
try{
  $page=1;
  require_once 'include/config.php';
  $conn = new mysqli(DB_HOST,DB_USER,DB_PASSWORD,DB_DATABASE);
  //$conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
  //$stmt = $conn->prepare("UPDATE EVENT SET start_time = '2014-10-10' where event_name='c'");
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>EVENT INFORMATION</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
  <style>.footer{ padding-left: 90%; padding-top: 20%; color: red; font-family: sans-serif; }
         .name{ font-family: sans-serif; color: #708090;}
         #page3{ color: #fcc39c; font-size: 20px;}
         .navbar-brand{ font-size: 22px; font-weight: bold; font-family: sans-serif;}</style>
</head>
<body>
  <nav class="navbar navbar-inverse">
  <div class="container-fliud">
    <div >
      <h3 class="navbar-brand" >     INSPIRON 15.0</h3>
    </div>
    <div>
      <ul class="nav navbar-nav navbar-right">
      <li><a href="home.html"><span class="glyphicon glyphicon-home"> Home</span></a></li>
      <li><a href="#"><span class="glyphicon glyphicon-list-alt"> Events</span></a></li>
      <li><a href="eventlist.php"><span id="page3" class="glyphicon glyphicon-time"> Timings</span></a></li>
      <li><a href="contactus.html"><span class="glyphicon glyphicon-envelope"> ReachUs</span></a></li>
      <li><a href="#"><span> </span></a></li>
      </ul>
    </div>
  </div>
</nav>
  <!--<h1 class="text-center bg-info text-success"><u><i>EVENT OVERVIEW</i></u></h1>-->
  <br/><br/>
  <div class="container">
  <h2 class="name">DAY 1(30 Oct 2015)</h2>
  <table class="table table-hover">
    <thead>
      <tr>
        <th class="bg-primary">EVENT NAME</th>
        <th class="bg-primary">TIMING</th>
        <th class="bg-primary">1st PRIZE(in INR)</th>
        <th class="bg-primary">2nd PRIZE(in INR)</th>
      </tr>
    </thead>
    <tbody>
      <?php
    $results=$conn->query('SELECT * FROM DAY1');
    foreach($results as $row)
    {
      ?><tr>
      <?php
      $count=1;
      foreach($row as $name=>$value)
      { if($count==1)
        { $count=2;
          echo "<td class=\"text-danger\"><a href=\"\">$value</a></th>";}
        else
        { echo "<td class=\"text-danger\">$value</th>";}
      }
      ?>
    </tr>
    <?php } ?>
    </tbody>
  </table><br/>
  <h2 class="name">DAY 2(31 Oct 2015)</h2>
  <table class="table table-hover">
    <thead>
      <tr>
        <th class="bg-primary">EVENT NAME</th>
        <th class="bg-primary">TIMING</th>
        <th class="bg-primary">1st PRIZE(in INR)</th>
        <th class="bg-primary">2nd PRIZE(in INR)</th>
      </tr>
    </thead>
    <tbody>
      <?php
    $results=$conn->query('SELECT * FROM DAY2');
    foreach($results as $row)
    {
      ?><tr>
      <?php
      $count=1;
      foreach($row as $name=>$value)
      { if($count==1)
        { $count=2;
          echo "<td class=\"text-danger\">$value</th>";}
        else
        { echo "<td class=\"text-info\">$value</th>";}
      }
      ?>
    </tr>
    <?php } ?>
    </tbody>
  </table>
</div>

</body>
<?php
  } 
catch(PDOException $e)
{
  echo 'ERROR: '.$e->getMessage();
}
?>
<div class="footer"><footer><?php include 'counter.php'; echo "Views: $count"; ?></footer></div>
</html> 