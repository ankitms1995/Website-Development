<?php
 
class DB_Functions {
 
    private $conn;
 
    // constructor
    function __construct() {
        require_once 'DB_Connect.php';
        // connecting to database
        $db = new Db_Connect();
        $this->conn = $db->connect();
    }
 
    // destructor
    function __destruct() {
         
    }
 
    /**
     * Storing new user
     * returns user details
     */
    public function storeUser($ticketno, $name, $phno, $email, $college, $event) {
        
        $stmt = $this->conn->prepare("INSERT INTO participant_details(TICKET_NO, NAME, PHONE_NO, EMAIL_ID, COLLEGE, EVENT) VALUES(?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $ticketno, $name, $phno, $email, $college, $event);
        $result = $stmt->execute();
        $stmt->close();
 
        // check for successful store
        if ($result) {
            $stmt = $this->conn->prepare("SELECT * FROM participant_details WHERE TICKET_NO = ?");
            $stmt->bind_param("s", $ticketno);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();
 
            return $user;
        } else {
            return false;
        }
    }
 
    /**
     * Check user is existed or not
     */
    public function isUserExisted($ticketno) {
        $stmt = $this->conn->prepare("SELECT TICKET_NO from participant_details WHERE TICKET_NO = ?");
 
        $stmt->bind_param("s", $ticketno);
 
        $stmt->execute();
 
        $stmt->store_result();
 
        if ($stmt->num_rows > 0) {
            // user existed 
            $stmt->close();
            return true;
        } else {
            // user not existed
            $stmt->close();
            return false;
        }
    }
 
}
 
?>
