<?php
	session_start();
	define('USERNAME','ankit');
	define('PASSWORD','ankit');
	if($_SERVER['REQUEST_METHOD']=='POST')
	{
		$username=$_POST['username'];
		$password=$_POST['password'];
		if($username===USERNAME && $password===PASSWORD)
		{
			$_SESSION['username']=$username;
			echo "<br/><li><a href=\"insertday1.php\">Insert into day 1</a></li>";
			echo "<br/><li><a href=\"insertday2.php\">Insert into day 2</a></li>";
			echo "<br/><li><a href=\"deleteday1.php\">Delete from day 1</a></li>";
			echo "<br/><li><a href=\"deleteday2.php\">Delete from day 2</a></li>";
			echo "<br/><li><a href=\"updateday1.php\">Update day 1</a></li>";
			echo "<br/><li><a href=\"updateday2.php\">Update day 2</a></li>";
			echo "<br/<br/><br/><a href=\"logout.php\">Logout</a>";
		}
		else
	{
?>
<!DOCTYPE html>
<html>
<head>
	<title>login</title>
</head>
<body>
<form action="login.php" method="post">
	<label for="username">username</label>
	<input type="text" name="username" id="username">
	<label for="password">password</label>
	<input type="password" name="password" id="password">
	<input type="submit" value="go">
</form>
<strong><br/><br/>Invalid login credentials</strong>
</body>
</html>
<?php } 
	}
	else
	{
?>
<!DOCTYPE html>
<html>
<head>
	<title>login</title>
</head>
<body>
<form action="login.php" method="post">
	<label for="username">username</label>
	<input type="text" name="username" id="username">
	<label for="password">password</label>
	<input type="password" name="password" id="password">
	<input type="submit" value="go">
</form>
</body>
</html>
<?php } ?>