<?php
session_start();
try{
	if(!isset($_SESSION['username']))
	{
		header('Location: login.php');
	}
	require_once 'include/config.php';
	$conn = new mysqli(DB_HOST,DB_USER,DB_PASSWORD,DB_DATABASE);
	//$conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
	?>
	<!DOCTYPE html>
	<html>
	<head>
		<title>updateday2</title>
	</head>
	<body>
	<form action="updateday2.php" method="post">
		<label for="event_name">event_name</label>
		<input type="text" name="event_name" id="event_name">
		<label for="start_time">start_time</label>
		<input type="text" name="start_time" id="start_time">
		<input type="submit" value="go">
	</form>
	</body>
	</html>
	<?php
	if($_SERVER['REQUEST_METHOD']=='POST')
	{
		if(isset($_POST['event_name']) && isset($_POST['start_time']))
		{
			$event_name=$_POST['event_name'];
			$start_time=$_POST['start_time'];
			$stmt = $conn->prepare("UPDATE DAY2 SET start_time=(?) WHERE event_name=(?)");
	    	$stmt->bind_param('ss',$start_time,$event_name);
	   	 	$result = $stmt->execute();
	    	$stmt->close();
	    	echo "Updated!<br\>";
	    }
		/*$results=$conn->query('SELECT * FROM DAY1');
		foreach($results as $row)
		{
			foreach($row as $name=>$value)
			{	echo $value;	
			}
			echo "</br>";
		}*/
	}
	/*else
	{
		echo "Not Post!";
	}*/
	echo '<br/><br/><a href="logout.php">logout</a>';
}	
catch(PDOException $e)
{
	echo 'ERROR: '.$e->getMessage();
}
?>
