<?php
require_once('connect/dbConnect.php');
?>
<!DOCTYPE>
<html>
	<head>
		<title>TechnicalSkills videos</title>
		<meta charset="utf-8">
		<link rel="stylesheet" href="css/bootstrap.min.css">
    	<link rel="stylesheet" type="text/css" href="css/modal.css">
    	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
       
	</head>
	<body class="container">
    	<div id="topmenu">
    		<nav class="navbar navbar-inverse navbar-fixed-top" id="topmenu" >
      			<div class="container-fluid">
      				
      				<div class="navbar-header">
          				<a class="navbar-brand" href="#"eLearning</a>
         			</div>
      				
      				<ul class="nav navbar-nav">
          				<!--<li class="active"><a href="#">Store</a></li>-->
          				<h4 style="margin-top: 0px;">eLearning</h4>
   					</ul>
     				
     				<ul class="nav navbar-nav navbar-right">
      					<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Skills Filter<span class="caret"></span></a>
          					<ul class="dropdown-menu">
        						<li><a href="LifeSkills.php">LifeSkills</a></li>
        						<li><a href="SocialSkills.php">SocialSkills</a></li>
        						<li><a href="SoftSkills.php">SoftSkills</a></li>
        						<li><a href="TechnicalSkills.php">TechnicalSkills</a></li>
        					</ul>      
        				</li>
      					<li> <a href="#" id="myBtn">Feedback</a></li>
        				<!--<li><a href="TechnicalSkills.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>-->
      				</ul>
      			
      			</div>
    		</nav>
  		</div>

  		<div class = "row" style="margin-top:100px; clear:both;">
  			<?php
  				$sql = "SELECT * FROM movie_info WHERE category = 'TechnicalSkills'";
  				$result = mysqli_query($con,$sql);
  				$i = 0;
  				foreach ($result as $row) {
  					$i += 1;
  					$image = $row['image_link'];
  					$movie = $row['movie_link'];
  					$name = $row['name'];
  					$desc = $row['desc']; ?>
   				
   					<div class = "col-sm-6 col-md-3">
      					<a href = "#" class = "thumbnail" id = <?php echo "myBtn".$i; ?> style = "text-decoration: none;">
         					<img src = <?php echo $image; ?> alt = "Generic placeholder thumbnail" style="height:150px; width:250px;">
         					<h2 ><?php echo $name; ?></h2>
      					</a>
    				</div>

    				<div id= "Feedback" class="modal">

   						<!-- Modal content -->
   						<div class="modal-content">
     						<span class="close">&times;</span>
         					<center>
         						<form action = "feedback.php" method="post">
         							<h4> Feedback</h4>
         							<textarea placeholder="Please type your feedback here" name="feedback" style="height: 200px; width: 650px; border-radius: 10px; border: thick;"></textarea>
         							<br />
         							<br />
         							<input type = "submit" value = "Submit" />
         						</form>
          					</center>        
   						</div>
  				
  					</div>

  					<div id= <?php echo "myModal".$i; ?> class="modal">

   						<!-- Modal content -->
   						<div class="modal-content">
     						<span class="close">&times;</span>
     					  	<img src = <?php echo $image; ?> alt = "Generic placeholder thumbnail" style="height:250px; width:300px;">
       						<div style="float: right; "><h2><?php echo $name; ?></h2>
       						<p><?php echo $desc; ?></p></div>
         					<center>
         						<form action = "play.php" method="post">
         							<input type = "hidden" name = "movie_name" value = <?php echo $movie ?> />
         							<input type="submit" value = "Play movie" />
         						</form>
          					</center>        
   						</div>
  				
  					</div>

				<?php } ?>
  	
			<script>
			// Get the modal
			<?php
			for($j=1; $j<=$i; $j++)
			{?>
				var modal<?php echo $j; ?> = document.getElementById("myModal<?php echo $j; ?>");

				// Get the button that opens the modal
				var btn<?php echo $j; ?> = document.getElementById("myBtn<?php echo $j; ?>");

				// Get the <span> element that closes the modal
				var span<?php echo $j; ?> = document.getElementsByClassName("close")[0];

				// When the user clicks the button, open the modal 
				btn<?php echo $j; ?>.onclick = function() {
	    			modal<?php echo $j; ?>.style.display = "block";
				}

				// When the user clicks on <span> (x), close the modal
				span<?php echo $j; ?>.onclick = function() {
    				modal<?php echo $j; ?>.style.display = "none";
				}

			<?php } ?>
	
			var feedback = document.getElementById("Feedback");

			// Get the button that opens the modal
			var btn = document.getElementById("myBtn");

			// Get the <span> element that closes the modal
			var span = document.getElementsByClassName("close")[0];

			// When the user clicks the button, open the modal 
			btn.onclick = function() {
	    		feedback.style.display = "block";
			}

			// When the user clicks on <span> (x), close the modal
			span.onclick = function() {
    			feedback.style.display = "none";
			}

			// When the user clicks anywhere outside of the modal, close it
			window.onclick = function(event) {
				<?php 
					for ($j = 1; $j<=$i; $j++) { ?>
    					if (event.target == modal<?php echo $j; ?>) {
        					modal<?php echo $j; ?>.style.display = "none";
    					}
    				<?php } ?>
			}

			</script>
		</div>
	</body> 
</html>