<?php
define("HOST","localhost");
define("USER","root");
define("PASSWORD","");
define("DB","eLearning");

$con = mysqli_connect(HOST,USER,PASSWORD,DB) or die("Unable to connect");
?>