<?php
	require_once('connect/dbConnect.php');
	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		$feedback = $_POST['feedback'];
		$sql = "INSERT INTO Feedback(feedback) VALUES('$feedback')";
  		$result = mysqli_query($con,$sql);
  		if($result)
  		{
  			echo "Your feedback has been recorded! Wait till we redirect.";
  			?>
  			<meta http-equiv="refresh" content="2;url=http://localhost/project_movies/index.php" />
  			<?php
  		}
  		else
  		{
  			echo "Error occured";
  		}
  	}
?>