<?php
require_once('connect/dbConnect.php');
?>
<!DOCTYPE>
<html>
	<head>
		<title>Movies</title>
		<meta charset="utf-8">
		<link rel="stylesheet" href="css/bootstrap.min.css">
    	<link rel="stylesheet" type="text/css" href="css/modal.css">
        <script src="js/jquery.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        
	</head>
	<body class="container">
    	<div id="topmenu">
    		<nav class="navbar navbar-inverse navbar-fixed-top" id="topmenu" >
      			<div class="container-fluid">
       				<div class="navbar-header">
          				<a class="navbar-brand" href="#">Movies</a>
         			</div>
      				<ul class="nav navbar-nav">
          				<li class="active"><a href="store.php">Store</a></li>
      					<li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Languages<span class="caret"></span></a>
          				<ul class="dropdown-menu">
        					<li><a href="english.php">English</a></li>
        					<li><a href="hindi.php">Hindi</a></li>
        					<li><a href="kannada.php">Kannada</a></li>
        				</ul>      
   					</ul>
     				<!--<ul class="nav navbar-nav navbar-right">
      				<!--<?php
     				// session_start();
      				//echo"<li class='active'><a href='#'>";
      				//echo $_SESSION['USER_NAME'];
      				//echo"</a></li>"; 
      				?>
      				<li> <a href="feedback.php">Feedback</a></li>
        			<li><a href="index.php"><span class="glyphicon glyphicon-log-out"></span>Logout</a></li>
      				</ul>-->
      			</div>
    		</nav>
  		</div>

  		<div class = "row" style="margin-top:100px; clear:both;">
  			<?php
  				$sql = "SELECT * FROM movie_info";
  				$result = mysqli_query($con,$sql);
  				$i = 0;
  				foreach ($result as $row) {
  					$i += 1;
  					$image = $row['image_link'];
  					$movie = $row['movie_link'];
  					$name = $row['name'];
  					$desc = $row['desc']; ?>
   					<div class = "col-sm-6 col-md-3">
      					<a href = "#" class = "thumbnail" id = <?php echo "myBtn".$i; ?> style = "text-decoration: none;">
         					<img src = <?php echo $image; ?> alt = "Generic placeholder thumbnail" style="height:150px; width:250px;">
         					<h2 ><?php echo $name; ?></h2>
      					</a>
    				</div>

  					<div id= <?php echo "myModal".$i; ?> class="modal">

   						<!-- Modal content -->
   						<div class="modal-content">
     						<span class="close">&times;</span>
     					  	<img src = <?php echo $image; ?> alt = "Generic placeholder thumbnail" style="height:250px; width:300px;">
       						<h2><?php echo $name; ?></h2>
       						<p><?php echo $desc; ?></p>
         					<center>
          						<div class = "video"><a href= <?php echo $movie; ?> target="_blank">Play movie</a></div>
          					</center>        
   						</div>
  					</div>

				<?php } ?>
  	
			<script>
			// Get the modal
			<?php
			for($j=1; $j<=$i; $j++)
			{?>
				var modal<?php echo $j; ?> = document.getElementById("myModal<?php echo $j; ?>");

				// Get the button that opens the modal
				var btn<?php echo $j; ?> = document.getElementById("myBtn<?php echo $j; ?>");

				// Get the <span> element that closes the modal
				var span<?php echo $j; ?> = document.getElementsByClassName("close")[0];

				// When the user clicks the button, open the modal 
				btn<?php echo $j; ?>.onclick = function() {
	    			modal<?php echo $j; ?>.style.display = "block";
				}

				// When the user clicks on <span> (x), close the modal
				span<?php echo $j; ?>.onclick = function() {
    				modal<?php echo $j; ?>.style.display = "none";
				}

			<?php } ?>
		
			// When the user clicks anywhere outside of the modal, close it
			window.onclick = function(event) {
				<?php 
					for ($j = 1; $j<=$i; $j++) { ?>
    					if (event.target == modal<?php echo $j; ?>) {
        					modal<?php echo $j; ?>.style.display = "none";
    					}
    				<?php } ?>
			}
			</script>
       
		</div>

	</body>	
</html>