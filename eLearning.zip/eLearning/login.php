<?php
	session_start();
	define('USERNAME','ankit');
	define('PASSWORD','ankit');
	if($_SERVER['REQUEST_METHOD']=='POST')
	{
		$username=$_POST['username'];
		$password=$_POST['password'];
		if($username===USERNAME && $password===PASSWORD)
		{
			$_SESSION['username']=$username;
			header('Location: movielist.php');
		}
		else
	{
?>
<!DOCTYPE html>
<html>
<head>
	<title>login</title>
</head>
<body>
<form action="login.php" method="post">
	<label for="username">username</label>
	<input type="text" name="username" id="username">
	<label for="password">password</label>
	<input type="password" name="password" id="password">
	<input type="submit" value="go">
</form>
<strong><br/><br/>Invalid login credentials</strong>
</body>
</html>
<?php } 
	}
	else
	{
?>
<!DOCTYPE html>
<html>
<head>
	<title>login</title>
</head>
<body>
<form action="login.php" method="post">
	<label for="username">username</label>
	<input type="text" name="username" id="username">
	<label for="password">password</label>
	<input type="password" name="password" id="password">
	<input type="submit" value="go">
</form>
</body>
</html>
<?php } ?>