<?php
session_start();
if(!isset($_SESSION['username']))
{
	header('Location: login.php');
}
?>
<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="play_button.css">
		<title>Movie List</title>
	</head>
	<body>
	<div class = "video">
		<a href="Day 1- Your First Webpage (30 Days to Learn HTML & CSS)_HD.mp4" target="_blank"><img src="img1.jpg" class="img-thumbnail" alt="Image 1"></a> 
	</div>
	</body>
</html>
