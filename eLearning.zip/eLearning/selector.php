<?php
	if($_SERVER['REQUEST_METHOD'] == 'POST')
	{
		echo "string";
		echo $_POST['language'];
	}
?>