<?php
 
 if($_SERVER['REQUEST_METHOD']=='POST'){
 	$job_id = $_POST['job_id'];
 	$email = $_POST['email'];
 
 	require_once('dbConnect.php');
 
 	$sql = "INSERT INTO applied (job_id,email,status) VALUES ('$job_id','$email','processing')";
 
 
 	if(mysqli_query($con,$sql)){
 		echo "Successfully Applied";
 	}else{
 		echo "You already applied for it";
 	}
 }
 else{
	echo 'error';
 }
 ?>