<?php 
 
 //Creating sql query
$list = array();
$email = $_POST['email'];
$i = 0;
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
	$sql = "SELECT j.job_id, j.employer, j.title, a.status FROM jobs j JOIN applied a on a.job_id = j.job_id WHERE email = '$email'";
 
	//importing dbConnect.php script 
	require_once('dbConnect.php');
 
	//executing query
	$result = mysqli_query($con,$sql);
 
	//fetching result
	//$check = mysqli_fetch_array($result);
 
	foreach ($result as $row) {
		# code...
	 	$list[$i] = $row;
	 	$i += 1;
	}
	$response = array('result'=>$list);
	$fp = fopen('results.json','w');
	fwrite($fp,json_encode($response));
	fclose($fp);
	//var_dump($response);
	echo json_encode($response);
	mysqli_close($con);
}
?>