<?php
 
if($_SERVER['REQUEST_METHOD']=='POST' && $_POST['fname'] != '' && $_POST['lname'] != '' && $_POST['phno'] != '' && $_POST['email'] != '' && $_POST['password'] != ''){
 	$fname = $_POST['fname'];
 	$lname = $_POST['lname'];
 	$phno = $_POST['phno'];
 	$email = $_POST['email'];
 	$password = $_POST['password'];
 
 	require_once('dbConnect.php');
 
 	$sql = "INSERT INTO users (fname,lname,phno,email,password) VALUES ('$fname','$lname','$phno','$email','$password')";
 
 
 	if(mysqli_query($con,$sql)){
 		echo "Successfully Registered";
 	}else{
 		echo "User already exists";
	}
}
else{
	echo 'error';
}
?>