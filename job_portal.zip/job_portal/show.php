<?php 
 
 //Creating sql query
$list = array();
$job_id = $_POST['job_id'];
$i = 0;
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
	$sql = "SELECT job_id, employer, title, about, skills, responsibilities FROM jobs WHERE job_id = '$job_id'";
 
	//importing dbConnect.php script 
	require_once('dbConnect.php');
 
	//executing query
	$result = mysqli_query($con,$sql);
 
	//fetching result
	//$check = mysqli_fetch_array($result);
 
	foreach ($result as $row) {
		# code...
	 	$list[$i] = $row;
	 	$i += 1;
	}
	$response = array('result'=>$list);
	$fp = fopen('results.json','w');
	fwrite($fp,json_encode($response));
	fclose($fp);
	//var_dump($response);
	echo json_encode($response);
	mysqli_close($con);
}
?>